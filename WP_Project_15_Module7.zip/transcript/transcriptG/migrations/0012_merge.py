# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('transcriptG', '0011_studentmarks'),
        ('transcriptG', '0009_document'),
    ]

    operations = [
    ]
