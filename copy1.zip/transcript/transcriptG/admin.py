from django.contrib import admin


from .models import Student,user,Document
admin.site.register(Student)
admin.site.register(user)
admin.site.register(Document)

